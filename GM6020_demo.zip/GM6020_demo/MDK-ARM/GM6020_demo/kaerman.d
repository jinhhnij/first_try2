gm6020_demo/kaerman.o: kaerman.c kaerman.h
